=== Moet ik naar de Dokter? - zelf triage ===
Contributors:      MINDD B.V.
Tags:              block
Requires at least: 5.6.0
Tested up to:      5.7.0
Stable tag:        1.1.1
Requires PHP:      7.0.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Installeer de zelf triage op uw eigen site.

== Description ==

== Shortcode ==

Basic usage of the shortcode:

	[mindd api_key=AB1CDE/FG2HIJ3KLMN4OPQRS5TUVWXYZ]

Attributes allowed in the shortcode:

 - *api_key* get a [API key](https://www.moetiknaardedokter.nl/informatie-voor-huisartsen/aanvraag-api-key/)
 - *welcome_text* Text to display, supports markdown
 - *widget_background* hex color
 - *widget_foreground* hex color
 - *branding_name* Name of practice
 - *branding_phone_label* Readable phone label
 - *branding_phone_number* The phone number that users can click.

== Changelog ==

= 0.3.0 =
* Added labels and shortcode

= 1.1.0 =
* Added accent color
* Renamed folder for update

= 1.1.1 =
* Added default color to mindd logo
